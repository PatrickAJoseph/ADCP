
#include <iostream>

#include "MPU_Stick.hpp"

/*
*	@brief:		Enable connection to device.
*/

void MPU_Stick::enable_transmission()
{
	this->_adcp.open_node_connection( this->_adcp.get_node_id("MPU_Stick"), 
									  this->retry_interval, 
									  this->number_of_tries );
}

/*
*	@brief:		Disable connection to device.
*/

void MPU_Stick::disable_transmission()
{
	this->_adcp.close_node_connection( this->_adcp.get_node_id("MPU_Stick"), 
									  this->retry_interval, 
									  this->number_of_tries );
}
