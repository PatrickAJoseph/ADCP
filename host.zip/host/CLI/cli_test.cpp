

#include <stdio.h>
#include "cli.hpp"

using namespace std;

int main(void)
{
  cli_init();
  cli();
	
  return(0);	 
}